# Deploying the portfolio with the AI agent widget

This project now has two parts:
- `index.html` — the site itself (unchanged design, plus a chat widget bottom-right)
- `api/chat.js` — a serverless function that talks to the Anthropic API on the site's behalf

The widget calls `/api/chat`, which only works on Vercel (or a similar host that runs
serverless functions). It will NOT work on GitHub Pages, since GitHub Pages only serves
static files and can't run the function or keep your API key secret.

## Steps to deploy on Vercel

1. Put `index.html`, the `api` folder (with `chat.js` inside it), and `package.json`
   together in one project folder — keep this exact structure:
   ```
   your-portfolio/
     index.html
     package.json
     api/
       chat.js
   ```
2. Go to vercel.com and sign in.
3. Click "Add New → Project" and either:
   - Drag-and-drop the whole `your-portfolio` folder, or
   - Push it to a GitHub repo first and import that repo (either works).
4. Before the first deploy finishes, go to Project Settings → Environment Variables and add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your actual Anthropic API key (from console.anthropic.com)
5. Deploy. Vercel gives you a live URL, and the chat widget will work immediately —
   no other setup needed.

## Cost note

Every question a visitor asks the widget makes one API call, billed to whichever
Anthropic account owns that API key. For portfolio-level traffic this is typically
a very small cost, but it isn't literally free the way the rest of the static site is.

## If you ever want to update what the agent knows

Open `api/chat.js` and edit the `SYSTEM_PROMPT` text block near the top — that's the
only place the agent's knowledge about Aravind lives. No other code needs to change.
